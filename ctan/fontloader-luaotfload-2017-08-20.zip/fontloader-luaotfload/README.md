# The fontloader-luaotfload package

Additional fontloaders for luaotfload

Version 1.0  Ulrike Fischer 2017-


## License

LATEX Project Public License 1.3c.

## Contents

- Readme.md (this file)
- various fontloader-XXXX.lua files 
- luaotfload-letterspace.luaX -- and alternative version of luaotfload-letterspace.lua, needed for some of the fontloaders
- luaotfload.confX -- an example configuration file, rename to luaotfload.conf to use it.
- fontloader-luaotfload.tex, fontloader-luaotfload.pdf (the docu and example)
- A number of test-XXX-files


## Use and Installation

Read the documentation.

